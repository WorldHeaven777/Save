<?php 
defined("GOV_APP") || die("!");
define("BASE_URL", "");
//DATABASE
define("DB_NAME", "nama_database");
define("DB_USER", "nama_user_database");
define("DB_PASSWORD", "password_database");
define("DB_HOST", "localhost");