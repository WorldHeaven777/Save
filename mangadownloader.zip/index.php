<?php 
//error_reporting(E_ALL);
ini_set('display_errors', 0);
define("GOV_APP", __DIR__);
define("ABSPATH", __DIR__);
require_once(__DIR__ . '/include/class/inc.php');
require_once(__DIR__ . '/include/class/Main.php');
require_once(__DIR__ . '/include/routes.php');
//START GET THE GET 
$post_id = isset($_GET['id']) ? $_GET['id'] : NULL;
if ( ! is_numeric($post_id)) View::show_404();
View::load("main", ["id" => $post_id]);
exit;