<?php 
View::load("header");
defined("GOV_APP") || die("!");
?>
<form method="POST" class="w3-container" >
    <p><h2 class="">Settings</h2></p>
    <p>
        <label class=""><b>Site URL</b></label>
        <input class="w3-input w3-border" type="text" name="base_url" value="<?php echo Config::get('base_url'); ?>" />
    </p>
    <p>
        <label class=""><b>Manga Site URL</b></label>
        <input class="w3-input w3-border" type="text" name="manga_site" value="<?php echo Config::get('manga_site'); ?>" />
    </p>
    <p>
        <label class=""><b>License Key</b></label>
        <input class="w3-input w3-border" type="text" name="license_key" value="<?php echo Config::get('license_key'); ?>" />
    </p>
    <p>
        <input class="w3-btn w3-black" type="submit" value="Save" />
    </p>
</form>
<?php View::load("footer");?>