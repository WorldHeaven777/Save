<?php View::load("header");?>
Open this and get the code <a href="<?=$authUrl?>" target="_blank">[LINK]</a>
<form method="POST" class="w3-row">
    <input type="hidden" name="token" value="<?php echo User::getToken();?>" />
	<input class="w3-input w3-half w3-border" type="text" name="acode" />
	<input class="w3-button w3-black" type="submit" value="Submit" />
</form>
<h3>How to add google drive account</h3>
1. Get the code by clicking link above.<br />
2. Login with your google drive account <br />
<img src="<?php echo Config::get('base_url');?>/assets/auth-tutor/do-auth-1.png" /><br />
3. Copy the code to input above<br />
<img src="<?php echo Config::get('base_url');?>/assets/auth-tutor/get-code.png" /><br />
4. Submit<br />
<img src="<?php echo Config::get('base_url');?>/assets/auth-tutor/submit.png" /><br />
<?php View::load("footer");?>