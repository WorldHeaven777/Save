    </div>
    <script>
        document.getElementById('gov-search-btn').addEventListener('click', function(){
            var ID = document.getElementById('gov-search').value;
            if (!ID || isNaN(ID)){
                alert("ID must be integer");
                return false;
            }
            window.location.assign('?page=admin/dashboard&id=' + ID);
            return false;
        });
    </script>
    </body>
</html>