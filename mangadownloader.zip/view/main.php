<?php 
defined("GOV_APP") || die("!");
$already_in_db = Storage::get_data($id);
if ($already_in_db != []){
    header("Location: https://drive.google.com/uc?id=".$already_in_db['drive_id']);
    exit;
}
if (Service::is_busy()){
	View::show_error('server sedang sibuk, coba lagi nanti, jika seperti ini terus, silahkan hubungi admin lewat fanspage / komen.');
	exit;
}
if ( ! isset($_GET['continue'])){
    View::load("main-view", ["id"=>$id]);
    exit;
}
Service::set_to_busy();

//check google client
$GClient = Drive::getClient();
if ( ! $GClient){
	Service::no_longer_busy();
	View::show_error("GClient error");
	exit;
}

$the_zip = Zip::do_zip($id);

if ($the_zip['error'] != FALSE){
	Service::no_longer_busy();
	View::show_error($the_zip['error']);
	exit;
}
if ( ! is_file($the_zip['file'])){
    Service::no_longer_busy();
	View::show_error("Oops! An Error Occured #znf");
	exit;
}
//begin UPLOAD
$GFile = Drive::upload($the_zip['file'], [
    'name' => $the_zip['name'],
]);
if ( ! $GFile){
    Service::no_longer_busy();
    View::show_error("Oops! An Error Occured #guf");
    exit;
}
$the_zip['drive_id'] = $GFile->id;

Storage::set_data([
    "drive_id" => $the_zip['drive_id'],
    "post_id" => $id,
    "size" => $the_zip['size'],
]);
unlink($the_zip['file']);

$perm = Drive::setPermission($the_zip['drive_id']);
if ($perm === NULL){
    Service::no_longer_busy();
    View::show_error("Oops! An Error Occured #gspf");
    exit;
}

Service::no_longer_busy();

header("Location: https://drive.google.com/uc?id=".$GFile->id);
exit;


