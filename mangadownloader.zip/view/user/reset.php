<?php 
defined("GOV_APP") || die("!");
View::load("header");
?>
<form method="POST" class="w3-container" >
    <input type="hidden" name="token" value="<?php echo User::getToken(); ?>" />
    <?php if (isset($error)) { ?> 
        <p><?php echo $error;?></p>
    <?php }?>
    <p><h2 class="">Reset Password</h2></p>
    <p>
        <label class=""><b>OLD password</b></label>
        <input class="w3-input w3-border" type="password" name="old" value="" />
    </p>
    <p>
        <label class=""><b>NEW password</b></label>
        <input class="w3-input w3-border" type="password" name="new" value="" />
    </p>
    <p>
        <label class=""><b>Confirm NEW password</b></label>
        <input class="w3-input w3-border" type="password" name="newconf" value="" />
    </p>
    <p>
        <input class="w3-btn w3-black" type="submit" value="Save" />
    </p>
</form>
<?php View::load("footer");?>